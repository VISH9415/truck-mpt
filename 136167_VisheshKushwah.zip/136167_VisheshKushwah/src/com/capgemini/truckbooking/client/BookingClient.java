package com.capgemini.truckbooking.client;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.dao.TruckDAO;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {

	public static void main(String[] args) throws BookingException {
		// TODO Auto-generated method stub

		TruckService truckService= new TruckService();
		TruckDAO truckDAO = new TruckDAO();
		BookingBean bookingBean = new BookingBean();
		TruckBean truckBean = new TruckBean();

		//CALL SERVICE LAYER FUNCTIONS
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter your customer id");
		String custId= sc.next();
		bookingBean.setCustId(custId);
		truckService.checkCustId(bookingBean);//validating customer id
		
		System.out.println("***Truck details***");
		truckService.retrieveTruckDetails();
		
		System.out.println("Please enter the truckid for truck to be booked: ");
		int truckId = sc.nextInt();
		truckService.checkTruckId(bookingBean,truckId);
		
		
		System.out.println("Please enter the number of trucks to be booked" );
		int truckno = sc.nextInt();
		truckService.checkNoOfTruck(bookingBean, truckId, truckno);
		
		System.out.println("Please enter your mobile no.");
		Long mob = sc.nextLong();
		bookingBean.setCustMobile(mob);
		
		//System.out.println("mobile entered: "+bookingBean.getCustMobile());
		System.out.println("Enter your date of transport in YYYY-MM-DD format: ");
		String date= sc.next();
		bookingBean.setDateOfTransport(date);
		
		//System.out.println("date entered: "+bookingBean.getDateOfTransport());
		int count= truckService.bookTrucks(bookingBean);
		if(count!=0)
		{
			int bookid = truckDAO.getBookingId();
			System.out.println("Your Bookingid is: "+bookid);
		}
		
		System.out.println("updated trucks table after booking is: ");
		truckService.updateTrucks(truckId,truckno);
		
		System.out.println("*****Booking details*****");
		int temp= truckService.bookTrucks(bookingBean);
		System.out.println(temp+" new records inserted in booking table");
		
		sc.close();		  		  
	}	
}
