package com.capgemini.truckbooking.dao;

//import com.capgemini.dto.StudentDTO;
import java.util.List;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bean.BookingBean;

public interface ITruckDAO {
	
	int getBookingId() throws BookingException;
	void retrieveTruckDetails() throws BookingException;
	int bookTrucks(BookingBean bookingBean) throws BookingException;
	int updateTrucks(int truckId,int noOfTruckToBook) throws BookingException;
}
