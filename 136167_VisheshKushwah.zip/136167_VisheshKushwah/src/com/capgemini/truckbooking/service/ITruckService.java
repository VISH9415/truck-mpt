package com.capgemini.truckbooking.service;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bean.BookingBean;

public interface ITruckService {

int bookTrucks(BookingBean bookingBean) throws BookingException;
int updateTrucks(int truckId,int noOfTruckToBook) throws BookingException;
void retrieveTruckDetails() throws BookingException;
void checkCustId(BookingBean bookingBean) throws BookingException;
public void checkTruckId(BookingBean bookingBean,int truckId) throws BookingException;
public void checkNoOfTruck(BookingBean bookingBean,int truckId,int truckno) throws BookingException;

}



