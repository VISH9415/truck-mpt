package com.capgemini.truckbooking.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.exception.BookingException;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.dao.TruckDAO;
import com.capgemini.utility.DBUtil;

public class TruckService implements ITruckService {

	BookingBean bookingBean = new BookingBean();
	TruckBean truckBean = new TruckBean();
	TruckDAO truckDAO = new TruckDAO();
	
	//CALL DAO FUNCTIONS
	Scanner sc = new Scanner(System.in);

	@Override
	public void retrieveTruckDetails() throws BookingException
	{
		truckDAO.retrieveTruckDetails();
	}
	
	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
	//System.out.println("Customer id entered is: "+bookingBean.getCustId());
	int bookid = truckDAO.getBookingId();
	bookingBean.setBookingID(bookid);
	//System.out.println("Your Bookingid is: "+bookingBean.getBookingID());
	int count = truckDAO.bookTrucks(bookingBean);
	//System.out.println(count+" records affected:");
	return count;
	}
    
	//int temp = TruckDAO.bookTrucks(bookingBean);

	@Override
	public int updateTrucks(int truckId, int noOfTruckToBook) throws BookingException
	{
	  System.out.println("*******Updated details of truck data******");
		truckDAO.updateTrucks(truckId,noOfTruckToBook);
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void checkCustId(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		String custid = "[A-Z]{1}[0-9]{1,6}";
		if(Pattern.matches(custid,bookingBean.getCustId())==false)
		{
				throw new BookingException("Customer Id is not in proper format");
				} 
		else{
			System.out.println("CustomerId entered is: "+bookingBean.getCustId());
		}
	    }
	
	public void checkTruckId(BookingBean bookingBean,int truckId) throws BookingException{

		int num=0;
		int i=0;
		int[] arr = new int[10];
		ResultSet res=null;
		Connection connStudent =null;
	    Statement st = null;
		try {
			connStudent = DBUtil.createConnection();
			st = connStudent.createStatement();
		    String sql1 = new String("SELECT TRUCKID from truckdetails");
			res = st.executeQuery(sql1);
			while (res.next()) {
				arr[i]=res.getInt(1); 
				i++;
			}
			//System.out.println("i = "+i);
			i=0;
			// checking if truckid entered is in the truckdetails table...
			while(i<arr.length)
			{
				if(truckId==arr[i]){
					num = num +1;
					break;
				}
				else{i = i+1;
					continue;}
			}
			//System.out.println("num ="+num);
		}catch (SQLException e) {
		}finally{
			try{
				DBUtil.closeConnection();
				//connStudent.close();
			}catch(SQLException se){
				throw new BookingException("Problems in closing connection");
			}	
		}
		if(num==0)
		{
			throw new BookingException("Truck ID entred is not valid!!");
		}
		else
		{
			bookingBean.setTruckId(truckId);
			System.out.println("CustomerId entered is: "+bookingBean.getTruckId());
		}
	}

	@Override
	public void checkNoOfTruck(BookingBean bookingBean,int truckId,int truckno) throws BookingException {
		// TODO Auto-generated method stub
		int arry=0;
		ResultSet res=null;
		Connection connStudent =null;
	    Statement st = null;
		try {
			connStudent = DBUtil.createConnection();
			st = connStudent.createStatement();
		    String sql1 = new String("SELECT AVAILABLENOS from truckdetails where TRUCKID= "+truckId);
			res = st.executeQuery(sql1);
			while (res.next()) {
				arry=res.getInt(1); 
			}
		}catch (SQLException e) {
		}finally{
			try{
				DBUtil.closeConnection();
				//connStudent.close();
			}catch(SQLException se){
				throw new BookingException("Problems in closing connection");
			}	
		}
		if(truckno>arry)
		{
			throw new BookingException("Number of Trucks entred is not valid!!");
		}
		else
		{
			bookingBean.setNoOfTrucks(truckno);
			System.out.println("Number of Trucks entered is: "+bookingBean.getNoOfTrucks());
		}
	}
	
	
	
	
	
}



